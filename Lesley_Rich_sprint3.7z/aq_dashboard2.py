from flask import Flask
from openaq import OpenAQ
from flask_sqlalchemy import SQLAlchemy

APP = Flask(__name__)

API = OpenAQ()

status, body = API.measurements(city='Los Angeles', parameter='pm25')

utc = {'utc': '2020-04-24T10:00:00.000Z',
       'value': 8}
utc = list(utc)



APP.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///db.sqlite3'
DB = SQLAlchemy(APP)


class Record(DB.Model):
    id = DB.Column(DB.Integer, primary_key=True)
    datetime = DB.Column(DB.String(25))
    value = DB.Column(DB.Float, nullable=False)

    def __repr__(self):
        utc_records = Record.query.all
        pprint(utc_records)
        return utc_records


@APP.route('/')
def root():
    condition = (Record.value >= 10)
    records = Record.query.filter(condition).all()
    pprint(records)
    return records

@APP.route('/refresh')
def refresh():
    """Pull fresh data from Open AQ and replace existing data."""
    DB.drop_all()
    DB.create_all()
    # TODO Get data from OpenAQ, make Record objects with it, and add to db
    DB.session.commit()
    return 'Data refreshed!'

